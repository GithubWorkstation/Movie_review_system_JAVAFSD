export interface Review {
    review: string;
    rating: number;
  }