export interface UpComingMovies {
    id: number;
    title: string;
    poster_path: string;
  }