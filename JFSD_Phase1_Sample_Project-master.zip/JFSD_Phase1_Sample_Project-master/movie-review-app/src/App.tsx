import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MovieList from "./pages/MovieList";
import MovieDetail from "./pages/MovieDetail";
import './App.css';
import UpcomingMovies from "./pages/UpcomingMovies";
function App() {
  return (

    <div>

<div className="advertisement-banner">
<UpcomingMovies/>

        <p>
          Check out the latest movies on{" "}
          <a
            href="https://www.pvrcinemas.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            PVR Cinemas
          </a>
          !
        </p>
      </div>
  <div className="main-content">
  
    <Router>
      <Routes>
        <Route path="/" element={<MovieList />} />
        <Route path="/movie/:id" element={<MovieDetail />} />
      </Routes>
    </Router>
  
    </div>
    <footer className="footer">
                <p>© 2025 Movie Review App. All rights reserved.</p>
    </footer>
    
    </div>
  );
}

export default App;
