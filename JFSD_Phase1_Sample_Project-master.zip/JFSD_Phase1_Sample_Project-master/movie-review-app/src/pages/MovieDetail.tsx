import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Movie } from "../types/Movie";
import { Review } from "../types/Review"; 

const API_URL = "http://localhost:3000/movies";

const MovieDetails = () => {
  const { id } = useParams<{ id: string }>();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [newReview, setNewReview] = useState("");
  const [newRating, setNewRating] = useState(5);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editedReview, setEditedReview] = useState("");
  const [editedRating, setEditedRating] = useState(5);

  useEffect(() => {
    fetch(`${API_URL}/${id}`)
      .then((res) => res.json())
      .then((data) => setMovie(data));
  }, [id]);

  const addReview = () => {
    if (!movie) return;

    const updatedReviews = [...movie.ratings, { review: newReview, rating: newRating }];

    fetch(`${API_URL}/${movie.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ratings: updatedReviews }),
    })
      .then((res) => res.json())
      .then((updatedMovie) => {
        setMovie(updatedMovie);
        setNewReview("");
        setNewRating(5);
      });
  };

  const deleteReview = (index: number) => {
    if (!movie) return;

    const updatedReviews = movie.ratings.filter((_, i) => i !== index);

    fetch(`${API_URL}/${movie.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ratings: updatedReviews }),
    })
      .then((res) => res.json())
      .then((updatedMovie) => setMovie(updatedMovie));
  };

  const startEditReview = (index: number) => {
    setEditingIndex(index);
    setEditedReview(movie?.ratings[index].review || "");
    setEditedRating(movie?.ratings[index].rating || 5);
  };

  const saveEditedReview = () => {
    if (!movie || editingIndex === null) return;

    const updatedReviews = [...movie.ratings];
    updatedReviews[editingIndex] = { review: editedReview, rating: editedRating };

    fetch(`${API_URL}/${movie.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ratings: updatedReviews }),
    })
      .then((res) => res.json())
      .then((updatedMovie) => {
        setMovie(updatedMovie);
        setEditingIndex(null);
        setEditedReview("");
        setEditedRating(5);
      });
  };

  return (
<div className="container mt-5">
      {movie ? (
        <>
          <div className="card shadow-lg">
            <div className="card-body">
              <h2 className="card-title">{movie.title}</h2>
              <p className="text-muted">Genre: {movie.genre}</p>

              <h3 className="mt-4">Reviews</h3>
              {movie.ratings.length > 0 ? (
                <ul className="list-group">
                  {movie.ratings.map((r, index) => (
                    <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
                      {editingIndex === index ? (
                        <div className="w-100">
                          <input
                            type="text"
                            className="form-control mb-2"
                            value={editedReview}
                            onChange={(e) => setEditedReview(e.target.value)}
                          />
                          <input
                            type="number"
                            className="form-control mb-2"
                            value={editedRating}
                            min="1"
                            max="5"
                            onChange={(e) => setEditedRating(Number(e.target.value))}
                          />
                          <button className="btn btn-success btn-sm me-2" onClick={saveEditedReview}>
                            Save
                          </button>
                        </div>
                      ) : (
                        <div>
                          <p className="mb-1">
                            <strong>Rating:</strong> ⭐ {r.rating}/5
                          </p>
                          <p className="mb-0">{r.review}</p>
                        </div>
                      )}

                      <div>
                        {editingIndex !== index && (
                          <>
                            <button className="btn btn-warning btn-sm me-2" onClick={() => startEditReview(index)}>
                              Edit
                            </button>
                            <button className="btn btn-danger btn-sm" onClick={() => deleteReview(index)}>
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted">No reviews yet.</p>
              )}

              <h3 className="mt-4">Add a Review</h3>
              <div className="input-group mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Write a review..."
                  value={newReview}
                  onChange={(e) => setNewReview(e.target.value)}
                />
                <input
                  type="number"
                  className="form-control"
                  value={newRating}
                  min="1"
                  max="5"
                  onChange={(e) => setNewRating(Number(e.target.value))}
                />
                <button className="btn btn-primary" onClick={addReview}>
                  Submit
                </button>
              </div>

              <Link to="/" className="btn btn-secondary mt-3">
                Back to Movies
              </Link>
            </div>
          </div>
        </>
      ) : (
        <p className="text-center">Loading...</p>
      )}
    </div>
  );
};

export default MovieDetails;

