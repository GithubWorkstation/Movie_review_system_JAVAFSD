import React, { useState, useEffect } from "react";
import "../UpcomingMovies.css";
import { UpComingMovies } from "../types/UpComingMovies";
// Define the type for a movie object
// interface Movie {
//   id: number;
//   title: string;
//   poster_path: string;
// }

const UpcomingMovies: React.FC = () => {
  const [movies, setMovies] = useState<UpComingMovies[]>([]);

  useEffect(() => {
    // Simulate fetching data from a fake service
    const fetchMockMovies = () => {
      const mockMovies: UpComingMovies[] = [
         {
          id: 2,
          title: "Mock Movie 2",
          poster_path: "/6DrHO1jr3qVrViUO6s6kFiAGM7.jpg", // TMDb poster path
        },
        {
          id: 3,
          title: "Mock Movie 3",
          poster_path: "/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg", // TMDb poster path
        },
        {
          id: 4,
          title: "Mock Movie 4",
          poster_path: "/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg", // TMDb poster path
        },
        {
          id: 5,
          title: "Mock Movie 5",
          poster_path: "/9n2tJBplPbgR2ca05hS5CKXwP2c.jpg", // TMDb poster path
        },
        {
          id: 6,
          title: "Mock Movie 6",
          poster_path: "/7ucaMpXAmlIM24qZZ8uI9hCY0hm.jpg", // TMDb poster path
        },
        {
          id: 7,
          title: "Mock Movie 7",
          poster_path: "/8YFL5QQVPy3AgrEQxNYVSgiPEbe.jpg", // TMDb poster path
        },
        {
          id: 8,
          title: "Mock Movie 8",
          poster_path: "/3CxUndGhUcZdt1Zggjdb2HkLLQX.jpg", // TMDb poster path
        },
        {
          id: 9,
          title: "Mock Movie 9",
          poster_path: "/5ik4ATKmNtmJU6AYD0bLm56BCVM.jpg", // TMDb poster path
        },
        {
          id: 10,
          title: "Mock Movie 10",
          poster_path: "/a2tys4sD7xzVaogPntGsT1ypVoT.jpg", // TMDb poster path
        },
      ];
      setMovies(mockMovies);
    };

    fetchMockMovies();
  }, []);

  return (
    <div className="upcoming-movies-container">
      <h2>Upcoming Movies</h2>
      <div className="movie-carousel">
        <div className="movie-track">
          {movies.concat(movies).map((movie, index) => (
            <div key={index} className="movie-item">
              <img
                src={`https://image.tmdb.org/t/p/w200${movie.poster_path}`}
                alt={movie.title}
              />
               </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UpcomingMovies;