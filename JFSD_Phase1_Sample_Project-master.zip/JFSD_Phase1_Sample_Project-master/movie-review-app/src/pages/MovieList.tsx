import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Movie } from "../types/Movie";
import { Review } from "../types/Review";
import "bootstrap/dist/css/bootstrap.min.css";

const API_URL = "http://localhost:3000/movies";

const MovieList = () => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All");

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => setMovies(data));
  }, []);

  const calculateAverageRating = (ratings: Review[]) => {
    if (ratings.length === 0) return "No Ratings";
    const total = ratings.reduce((sum, r) => sum + r.rating, 0);
    return (total / ratings.length).toFixed(1);
  };

  const genres = ["All", ...new Set(movies.map((movie) => movie.genre))];

  const filteredMovies = movies.filter((movie) => {
    return (
      (selectedGenre === "All" || movie.genre === selectedGenre) &&
      movie.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4 fw-bold text-primary">
        🎬 Welcome to Movie Review System
      </h1>

      {/* Search & Filter */}
      <div className="d-flex justify-content-between mb-4">
        <input
          type="text"
          className="form-control w-50"
          placeholder="🔍 Search movies..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <select
          className="form-select w-25"
          value={selectedGenre}
          onChange={(e) => setSelectedGenre(e.target.value)}
        >
          {genres.map((genre, index) => (
            <option key={index} value={genre}>
              {genre}
            </option>
          ))}
        </select>
      </div>

      {/* Movie Grid */}
      <div className="row">
        {filteredMovies.length > 0 ? (
          filteredMovies.map((movie) => (
            <div key={movie.id} className="col-md-4 col-lg-3 mb-4">
              <div className="card shadow-lg h-100 border-0">
                <img
                  src={movie.image}
                  className="card-img-top img-fluid"
                  alt={movie.title}
                  style={{ height: "300px", objectFit: "cover" }}
                />
                <div className="card-body text-center">
                  <h5 className="card-title">{movie.title}</h5>
                  <p className="text-muted">{movie.genre}</p>
                  <p className="fw-bold text-warning">
                    ⭐ {calculateAverageRating(movie.ratings)}
                  </p>
                  <Link to={`/movie/${movie.id}`} className="btn btn-primary">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-muted">No movies found.</p>
        )}
      </div>
    </div>
  );
};
export default MovieList;
